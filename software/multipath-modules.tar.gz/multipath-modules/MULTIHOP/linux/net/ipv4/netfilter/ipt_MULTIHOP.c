/* 
 * Kernel module to send a copy of the packet to each next-hop from the routing table
 * 
 * Copyright (C) 2006 DSN Lab, The Johns Hopkins University <smesh@dsn.jhu.edu>
 */

#include <linux/module.h>
#include <linux/skbuff.h>
#include <linux/ip.h>
#include <net/checksum.h>
#include <net/ip_fib.h>
#include <linux/if_arp.h>
#include <linux/netfilter_ipv4/ip_tables.h>

// 4 debugging
#define MACPF	"%.2X:%.2X:%.2X:%.2X:%.2X:%.2X"
#define MAC(m)	(unsigned char) m[0],\
				(unsigned char) m[1],\
				(unsigned char) m[2],\
				(unsigned char) m[3],\
				(unsigned char) m[4],\
				(unsigned char) m[5]

MODULE_AUTHOR("DSN Lab");
MODULE_DESCRIPTION("iptables MULTIHOP module");
MODULE_LICENSE("GPL");

static inline int my_ip_finish_output2(struct sk_buff *skb, u32 gateway, struct net_device *dev)
{
#ifdef CONFIG_NETFILTER_DEBUG
	nf_debug_ip_finish_output2(skb);
#endif /*CONFIG_NETFILTER_DEBUG*/

	int hh_alen;
	struct ethhdr eth;
	struct neighbour *n;
	u32 saddr;
	
	// search in the ARP cache...
	skb->dev = dev;
	n = neigh_lookup(&arp_tbl, &gateway, skb->dev);
	if (n) {	
/* debug
		printk(KERN_DEBUG "MULTIHOP: my_ip_finish_output2: neigh_lookup(%u.%u.%u.%u) found "MACPF"\n", NIPQUAD(gateway), MAC(n->ha));
		memcpy(eth.h_dest, n->ha, 6);
*/	
		// the source MAC is not in the ARP cache... take it from the device info
/* debug
		printk(KERN_DEBUG "MULTIHOP: my_ip_finish_output2: my MAC is "MACPF"\n", MAC(skb->dev->dev_addr));
*/
		memcpy(eth.h_source, skb->dev->dev_addr, 6);

/* debug
		printk(KERN_DEBUG "MULTIHOP: my_ip_finish_output2: before memcpy()\n");
*/	
		eth.h_proto = 8;
		hh_alen = 16;
	  	memcpy(skb->data - hh_alen + 2, (u8*)(&eth), hh_alen - 2);
/* debug	
		printk(KERN_DEBUG "MULTIHOP: my_ip_finish_output2: after memcpy()\n");	
		printk(KERN_DEBUG "MULTIHOP: my_ip_finish_output2: len = %d debug = %d dest = "MACPF" source = "MACPF" proto = %d\n",
						hh_alen,
						HH_DATA_OFF(sizeof(struct ethhdr)),
				   		MAC(eth.h_dest),
						MAC(eth.h_source),
						eth.h_proto);
*/					
		skb_push(skb, hh_alen - 2);
		return dev_queue_xmit(skb);
	} else {
/* debug
		printk(KERN_DEBUG "MULTIHOP: my_ip_finish_output2: neigh_lookup(%u.%u.%u.%u) error...\n", NIPQUAD(gateway));
*/
		// try to resolve neighbor...
/* debug
		printk(KERN_DEBUG "MULTIHOP: my_ip_finish_output2: arp request:\n");
		printk(KERN_DEBUG "MULTIHOP: dest IP:\t%u.%u.%u.%u\n", NIPQUAD(gateway));
		printk(KERN_DEBUG "MULTIHOP: device:\t%s\n", dev->name);
		printk(KERN_DEBUG "MULTIHOP: src IP (iph->saddr):\t%u.%u.%u.%u\n", NIPQUAD(skb->nh.iph->saddr));
*/
		saddr = inet_select_addr(dev, gateway, RT_SCOPE_LINK);
/* debug
		printk(KERN_DEBUG "MULTIHOP: src IP (inet_select_addr):\t%u.%u.%u.%u\n", NIPQUAD(saddr));
		printk(KERN_DEBUG "MULTIHOP: src hw (dev->dev_addr):\t%s\n", dev->dev_addr);
		printk(KERN_DEBUG "MULTIHOP: src hw (dev->addr_len):\t%d\n", dev->addr_len);
*/		
		if (dev->flags & IFF_NOARP) {
			// tunnel...
			printk("MULTIHOP: my_ip_finish_output2: tunnel? ;) \n");
			return dev_queue_xmit(skb);
		} else {
			printk("MULTIHOP: my_ip_finish_output2: ARP request sent, packet queued... \n");
			n = neigh_create(&arp_tbl, &gateway, dev);
			arp_send(ARPOP_REQUEST, ETH_P_ARP, gateway, dev, saddr, NULL, dev->dev_addr, NULL);
			n->nud_state = NUD_INCOMPLETE; // request sent, waiting for a reply
			struct dst_entry *dst;
			dst = dst_alloc(skb->dst->ops);
			memcpy(dst, skb->dst, sizeof(struct dst_entry));
			skb->dst = dst;
			skb->dst->neighbour = n;
			return neigh_event_send(n, skb);
		}
	}		
}

static unsigned int
target(struct sk_buff **pskb,
       unsigned int hooknum,
       const struct net_device *in,
       const struct net_device *out,
       const void *targinfo,
       void *userinfo)
{
	struct iphdr *iph = (*pskb)->nh.iph;
	struct sk_buff *newskb;
	
	// search in the routing table...
	
	struct rt_key key;
	struct fib_result res;
	int err;
	int nhsel;
	struct fib_nh *nh;
	struct fib_info *fi;

	key.dst = iph->daddr;
	key.src = iph->saddr;
	key.tos = iph->tos;
	key.oif = 0;
#ifdef CONFIG_IP_ROUTE_FWMARK
	key.fwmark = (*pskb)->nfmark;
#endif	
	key.iif = (*pskb)->dev->ifindex;
	key.scope = RT_SCOPE_UNIVERSE;

	if ((err = fib_lookup(&key, &res)) != 0) {
		printk(KERN_DEBUG "MULTIHOP: target: no route found...\n");
	} else {
		fi = res.fi;
		nh = (struct fib_nh*) (fi->fib_nh);	
/* debug
		printk(KERN_DEBUG "\nMULTIHOP: -------------------------\n");
		printk(KERN_DEBUG "MULTIHOP: target: fib_lookup(%u.%u.%u.%u) ok: %d entries:\n", NIPQUAD(iph->daddr), fi->fib_nhs);
*/
		if (fi->fib_nhs > 1) {
			for (nhsel = 0; nhsel < fi->fib_nhs; nh++, nhsel++) {
/* debug
				printk(KERN_DEBUG "MULTIHOP: -->entry %u.%u.%u.%u (%u.%u.%u.%u)", NIPQUAD(nh->nh_gw), NIPQUAD(((struct rtable*)((*pskb)->dst))->rt_gateway));
*/
				if (nh->nh_gw == 0 || ((struct rtable*)((*pskb)->dst))->rt_gateway == nh->nh_gw) {
//					printk(KERN_DEBUG "... skipped\n");
					continue;
				}
//				printk(KERN_DEBUG "\n");
				newskb = skb_copy(*pskb, GFP_ATOMIC);
				if (newskb) {
/* debug
					printk(KERN_DEBUG "MULTIHOP: target: Sending a copy of the packet...\n");
*/
					my_ip_finish_output2(newskb, nh->nh_gw, nh->nh_dev);

				}
			}
		}
	}	
	return IPT_CONTINUE;
}

static int
checkentry(const char *tablename,
		   const struct ipt_entry *e,
           void *targinfo,
           unsigned int targinfosize,
           unsigned int hook_mask)
{
	if (strcmp(tablename, "mangle") != 0) {
		printk(KERN_WARNING "MULTIHOP: can only be called from \"mangle\" table, not \"%s\"\n", tablename);
		return 0;
	}
	return 1;
}

static struct ipt_target ipt_multihop_reg
= { { NULL, NULL }, "MULTIHOP", target, checkentry, NULL, THIS_MODULE };

static int __init init(void)
{
	if (ipt_register_target(&ipt_multihop_reg))
		return -EINVAL;

	return 0;
}

static void __exit fini(void)
{
	ipt_unregister_target(&ipt_multihop_reg);
}

module_init(init);
module_exit(fini);
