/* 
 * Shared library add-on to iptables to add IPID target support
 *
 * Copyright (C) 2006 DSN Lab, The Johns Hopkins University
 *
 * libipt_IPID.c 07/13/2006
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>

#include <iptables.h>
#include <linux/netfilter_ipv4/ip_tables.h>
#include <linux/netfilter_ipv4/ipt_IPID.h>

static void help(void) 
{
	printf(
"IPID target options\n"
"  --set-ipid value		Set ID field in packet header to value\n"
"  		                This value must be in decimal (ex: 42)\n"
);
}

static struct option opts[] = {
	{ "set-ipid", 1, 0, 'I' },
	{ 0 }
};

static void init(struct ipt_entry_target *t, unsigned int *nfcache) 
{
}

static void
parse_ipid(const char *s, struct ipt_ipid_target_info *info)
{
	unsigned int ipid;
       
	if (string_to_number(s, 0, 255, &ipid) == -1)
		exit_error(PARAMETER_PROBLEM, "Invalid ipid `%s'\n", s);
	info->ipid = (u_int16_t) ipid;
	return;
}

static int
parse(int c, char **argv, int invert, unsigned int *flags,
      const struct ipt_entry *entry,
      struct ipt_entry_target **target)
{
	struct ipt_ipid_target_info *info = (struct ipt_ipid_target_info *)(*target)->data;

	switch (c) {
	case 'I':
		if (*flags)
			exit_error(PARAMETER_PROBLEM, "IPID target: Cannot use --set-ipid twice");
		parse_ipid(optarg, info);
		*flags = 1;
		break;

	default:
		return 0;
	}

	return 1;
}

static void
final_check(unsigned int flags)
{
	if (!flags)
		exit_error(PARAMETER_PROBLEM,
		           "IPID target: Parameter --set-ipid is required");
}

static void
print_ipid(u_int16_t ipid, int numeric)
{
 	printf("%d (0x%02x) ", ipid, ipid);
}

/* Prints out the targinfo. */
static void
print(const struct ipt_ip *ip,
      const struct ipt_entry_target *target,
      int numeric)
{
	const struct ipt_ipid_target_info *info =
		(const struct ipt_ipid_target_info *)target->data;
	printf("IPID set ");
	print_ipid(info->ipid, numeric);
}

/* Saves the union ipt_targinfo in parsable form to stdout. */
static void
save(const struct ipt_ip *ip, const struct ipt_entry_target *target)
{
	const struct ipt_ipid_target_info *info =
		(const struct ipt_ipid_target_info *)target->data;

	printf("--set-ipid %d ", info->ipid);
}

static struct iptables_target ipid = {
	.next		= NULL,
	.name		= "IPID",
	.version	= IPTABLES_VERSION,
	.size		= IPT_ALIGN(sizeof(struct ipt_ipid_target_info)),
	.userspacesize	= IPT_ALIGN(sizeof(struct ipt_ipid_target_info)),
	.help		= &help,
	.init		= &init,
	.parse		= &parse,
	.final_check	= &final_check,
	.print		= &print,
	.save		= &save,
	.extra_opts	= opts
};

void _init(void)
{
	register_target(&ipid);
}
