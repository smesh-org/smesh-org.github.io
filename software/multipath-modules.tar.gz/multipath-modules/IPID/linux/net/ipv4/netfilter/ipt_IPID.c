/* 
 * Kernel module to set the identifier field from the IP header (IPID)
 * 
 * Copyright (C) 2006 DSN Lab, The Johns Hopkins University <smesh@dsn.jhu.edu>
 *  
 */

#include <linux/module.h>
#include <linux/skbuff.h>
#include <linux/ip.h>
#include <net/checksum.h>

#include <linux/netfilter_ipv4/ip_tables.h>
#include <linux/netfilter_ipv4/ipt_IPID.h>

MODULE_AUTHOR("DSN Lab");
MODULE_DESCRIPTION("iptables IPID modification module");
MODULE_LICENSE("GPL");

static unsigned int
target(struct sk_buff **pskb,
       unsigned int hooknum,
       const struct net_device *in,
       const struct net_device *out,
       const void *targinfo,
       void *userinfo)
{
	struct iphdr *iph = (*pskb)->nh.iph;
	const struct ipt_ipid_target_info *ipidinfo = targinfo;

	if (iph->id != ipidinfo->ipid) {
		/* raw socket (tcpdump) may have clone of incoming
                   skb: don't disturb it --RR */
		if (skb_cloned(*pskb) && !(*pskb)->sk) {
			struct sk_buff *nskb = skb_copy(*pskb, GFP_ATOMIC);
			if (!nskb)
				return NF_DROP;
			kfree_skb(*pskb);
			*pskb = nskb;
			iph = (*pskb)->nh.iph;
		}

		iph->id = htons(ipidinfo->ipid);
		iph->check = 0;
		iph->check = ip_fast_csum((void *) iph, iph->ihl);
		(*pskb)->nfcache |= NFC_ALTERED;
	}
	return IPT_CONTINUE;
}

static int
checkentry(const char *tablename,
		   const struct ipt_entry *e,
           void *targinfo,
           unsigned int targinfosize,
           unsigned int hook_mask)
{
	const u_int16_t ipid = ((struct ipt_ipid_target_info *)targinfo)->ipid;

	if (targinfosize != IPT_ALIGN(sizeof(struct ipt_ipid_target_info))) {
		printk(KERN_WARNING "IPID: targinfosize %u != %Zu\n",
		       targinfosize,
		       IPT_ALIGN(sizeof(struct ipt_ipid_target_info)));
		return 0;
	}

	if (strcmp(tablename, "mangle") != 0) {
		printk(KERN_WARNING "IPID: can only be called from \"mangle\" table, not \"%s\"\n", tablename);
		return 0;
	}

	if (ipid > 255) {
		printk(KERN_WARNING "IPID: bad IPID values %#x\n", ipid);
		return 0;
	}
	
	return 1;
}

static struct ipt_target ipt_ipid_reg
= { { NULL, NULL }, "IPID", target, checkentry, NULL, THIS_MODULE };

static int __init init(void)
{
	if (ipt_register_target(&ipt_ipid_reg))
		return -EINVAL;

	return 0;
}

static void __exit fini(void)
{
	ipt_unregister_target(&ipt_ipid_reg);
}

module_init(init);
module_exit(fini);
