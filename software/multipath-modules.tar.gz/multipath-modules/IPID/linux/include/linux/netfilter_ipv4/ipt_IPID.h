#ifndef _IPT_IPID_H_target
#define _IPT_IPID_H_target

struct ipt_ipid_target_info {
	u_int16_t ipid;
};

#endif /*_IPT_IPID_H_target*/
